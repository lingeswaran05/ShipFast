package com.shipfast.auth.config;

public class JwtAuthenticationFilter {
}
