package com.shipfast.auth.service;

import com.shipfast.auth.dto.*;
import com.shipfast.auth.entity.*;
import com.shipfast.auth.repository.*;
import com.shipfast.auth.security.JwtService;
import com.shipfast.auth.exception.ResourceNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class AuthService {

    private final UserAuthRepository userRepo;
    private final RefreshTokenRepository refreshRepo;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UserAuthRepository userRepo,
                       RefreshTokenRepository refreshRepo,
                       JwtService jwtService,
                       PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.refreshRepo = refreshRepo;
        this.jwtService = jwtService;
        this.passwordEncoder = passwordEncoder;
    }

    public AuthResponse register(RegisterRequest request) {

        UserAuth user = new UserAuth();
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(UserRole.valueOf(request.getRole()));

        userRepo.save(user);

        String accessToken = jwtService.generateToken(user.getUserId(), user.getRole().name());
        String refreshToken = createRefreshToken(user.getUserId());

        return buildResponse(user, accessToken, refreshToken);
    }

    public AuthResponse login(LoginRequest request) {

        UserAuth user = userRepo.findByEmail(request.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("Invalid email or password"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new ResourceNotFoundException("Invalid email or password");
        }

        String accessToken = jwtService.generateToken(user.getUserId(), user.getRole().name());
        String refreshToken = createRefreshToken(user.getUserId());

        return buildResponse(user, accessToken, refreshToken);
    }

    public AuthResponse refreshToken(RefreshRequest request) {

        RefreshToken token = refreshRepo.findByToken(request.getRefreshToken())
                .orElseThrow(() -> new ResourceNotFoundException("Invalid refresh token"));

        if (token.getExpiryDate().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Refresh token expired");
        }

        UserAuth user = userRepo.findByUserId(token.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        String newAccessToken = jwtService.generateToken(user.getUserId(), user.getRole().name());

        return buildResponse(user, newAccessToken, token.getToken());
    }

    private String createRefreshToken(String userId) {
        RefreshToken token = new RefreshToken();
        token.setUserId(userId);
        token.setToken(UUID.randomUUID().toString());
        token.setExpiryDate(LocalDateTime.now().plusDays(7));
        refreshRepo.save(token);
        return token.getToken();
    }

    private AuthResponse buildResponse(UserAuth user,
                                       String accessToken,
                                       String refreshToken) {
        return new AuthResponse(
                user.getUserId(),
                user.getEmail(),
                user.getRole(),
                accessToken,
                refreshToken
        );
    }
}