package com.shipfast.auth.repository;

import com.shipfast.auth.entity.UserAuth;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserAuthRepository extends JpaRepository<UserAuth, Long> {

    Optional<UserAuth> findByEmail(String email);

    Optional<UserAuth> findByUserId(String userId);
}