package com.shipfast.auth.controller;

import com.shipfast.auth.dto.*;
import com.shipfast.auth.service.AuthService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService service;

    public AuthController(AuthService service) {
        this.service = service;
    }

    @PostMapping("/register")
    public ApiResponse<AuthResponse> register(@RequestBody RegisterRequest request) {
        return new ApiResponse<>(true, "Registered successfully",
                service.register(request));
    }

    @PostMapping("/login")
    public ApiResponse<AuthResponse> login(@RequestBody LoginRequest request) {
        return new ApiResponse<>(true, "Login successful",
                service.login(request));
    }

    @PostMapping("/forgot-password")
    public ApiResponse<?> forgot(@RequestBody ForgotPasswordRequest request) {
        service.forgotPassword(request);
        return new ApiResponse<>(true, "OTP sent to email", null);
    }

    @PostMapping("/reset-password")
    public ApiResponse<?> reset(@RequestBody ResetPasswordRequest request) {
        service.resetPassword(request);
        return new ApiResponse<>(true, "Password reset successful", null);
    }

    @PostMapping("/change-password")
    public ApiResponse<?> changePassword(
            @RequestBody ChangePasswordRequest request,
            @RequestHeader("Authorization") String authHeader) {

        String token = authHeader.substring(7);
        String userId = service.extractUserIdFromToken(token);

        service.changePassword(request, userId);

        return new ApiResponse<>(true, "Password changed successfully", null);
    }
}