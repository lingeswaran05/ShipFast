package com.shipfast.auth.service;

import com.shipfast.auth.dto.*;
import com.shipfast.auth.entity.*;
import com.shipfast.auth.repository.*;
import com.shipfast.auth.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Random;
import java.util.UUID;

@Service
public class AuthService {

    private final UserAuthRepository userRepo;
    private final RefreshTokenRepository refreshRepo;
    private final PasswordResetOtpRepository otpRepo;
    private final JwtService jwtService;
    private final PasswordEncoder encoder;
    private final EmailService emailService;

    public AuthService(UserAuthRepository userRepo,
                       RefreshTokenRepository refreshRepo,
                       PasswordResetOtpRepository otpRepo,
                       JwtService jwtService,
                       PasswordEncoder encoder,
                       EmailService emailService) {
        this.userRepo = userRepo;
        this.refreshRepo = refreshRepo;
        this.otpRepo = otpRepo;
        this.jwtService = jwtService;
        this.encoder = encoder;
        this.emailService = emailService;
    }

    public AuthResponse register(RegisterRequest request) {
        UserAuth user = new UserAuth();
        user.setEmail(request.getEmail());
        user.setPassword(encoder.encode(request.getPassword()));
        user.setRole(UserRole.valueOf(request.getRole()));
        userRepo.save(user);

        return generateAuthResponse(user);
    }

    public AuthResponse login(LoginRequest request) {
        UserAuth user = userRepo.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email or password"));

        if (!encoder.matches(request.getPassword(), user.getPassword()))
            throw new RuntimeException("Invalid email or password");

        return generateAuthResponse(user);
    }

    public void forgotPassword(ForgotPasswordRequest request) {
        UserAuth user = userRepo.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Email not found"));

        String otp = String.valueOf(100000 + new Random().nextInt(900000));

        PasswordResetOtp entity = new PasswordResetOtp();
        entity.setUserId(user.getUserId());
        entity.setOtp(otp);
        entity.setExpiryTime(LocalDateTime.now().plusMinutes(10));
        entity.setUsed(false);
        otpRepo.save(entity);

        emailService.sendOtp(user.getEmail(), otp);
    }

    public void resetPassword(ResetPasswordRequest request) {

        PasswordResetOtp otp = otpRepo.findByOtp(request.getOtp())
                .orElseThrow(() -> new RuntimeException("Invalid OTP"));

        if (otp.isUsed() || otp.getExpiryTime().isBefore(LocalDateTime.now()))
            throw new RuntimeException("OTP expired");

        UserAuth user = userRepo.findByUserId(otp.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setPassword(encoder.encode(request.getNewPassword()));
        userRepo.save(user);

        otp.setUsed(true);
        otpRepo.save(otp);
    }

    public void changePassword(ChangePasswordRequest request, String userId) {

        UserAuth user = userRepo.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!encoder.matches(request.getOldPassword(), user.getPassword()))
            throw new RuntimeException("Old password incorrect");

        if (encoder.matches(request.getNewPassword(), user.getPassword()))
            throw new RuntimeException("New password must be different");

        user.setPassword(encoder.encode(request.getNewPassword()));
        userRepo.save(user);
    }

    private AuthResponse generateAuthResponse(UserAuth user) {
        String accessToken = jwtService.generateToken(user.getUserId(), user.getRole().name());
        String refreshToken = UUID.randomUUID().toString();
        return new AuthResponse(user.getUserId(), user.getEmail(),
                user.getRole(), accessToken, refreshToken);
    }
    public String extractUserIdFromToken(String token) {
        return jwtService.extractUserId(token);
    }
}