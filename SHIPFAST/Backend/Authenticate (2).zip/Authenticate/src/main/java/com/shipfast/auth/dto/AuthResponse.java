package com.shipfast.auth.dto;

import com.shipfast.auth.entity.UserRole;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthResponse {

    private String userId;
    private String email;
    private UserRole role;
    private String accessToken;
    private String refreshToken;
}
