package com.shipfast.auth.service;

import com.shipfast.auth.dto.*;
import com.shipfast.auth.entity.*;
import com.shipfast.auth.exception.CustomException;
import com.shipfast.auth.repository.*;
import com.shipfast.auth.security.JwtService;
import com.shipfast.auth.utility.*;
import jakarta.transaction.Transactional;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuthServiceImpl implements AuthService {

    private final EmailService emailService;
    private final UserAuthRepository userAuthRepository;
    private final UserProfileRepository userProfileRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordResetOtpRepository otpRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthServiceImpl(
            EmailService emailService,
            UserAuthRepository userAuthRepository,
            UserProfileRepository userProfileRepository,
            RefreshTokenRepository refreshTokenRepository,
            PasswordResetOtpRepository otpRepository,
            BCryptPasswordEncoder passwordEncoder,
            JwtService jwtService
    ) {
        this.emailService = emailService;
        this.userAuthRepository = userAuthRepository;
        this.userProfileRepository = userProfileRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.otpRepository = otpRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    // ================= REGISTER =================

    @Override
    @Transactional
    public AuthResponse register(RegisterRequest request) {

        if (userAuthRepository.existsByEmail(request.getEmail()))
            throw new CustomException("Email already registered");

        if (userProfileRepository.existsByPhoneNumber(request.getPhoneNumber()))
            throw new CustomException("Phone number already registered");

        if (!PasswordValidator.isValid(request.getPassword()))
            throw new CustomException("Password does not meet security requirements");

        String userId = UserIdGenerator.generateUserId();

        UserAuth userAuth = new UserAuth();
        userAuth.setUserId(userId);
        userAuth.setEmail(request.getEmail());
        userAuth.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        userAuth.setRole(request.getRole() != null ? request.getRole() : UserRole.CUSTOMER);

        userAuthRepository.save(userAuth);

        UserProfile profile = new UserProfile();
        profile.setUserAuth(userAuth);
        profile.setFullName(request.getFullName());
        profile.setPhoneNumber(request.getPhoneNumber());
        profile.setAddress(request.getAddress());
        profile.setCity(request.getCity());
        profile.setState(request.getState());
        profile.setPincode(request.getPincode());

        userProfileRepository.save(profile);

        String accessToken = jwtService.generateAccessToken(userAuth.getEmail(), userAuth.getRole().name());
        String refreshToken = jwtService.generateRefreshToken(userAuth.getEmail());

        saveRefreshToken(userId, refreshToken);

        return new AuthResponse(userId, accessToken, refreshToken, userAuth.getRole().name());
    }

    // ================= LOGIN =================

    @Override
    @Transactional
    public AuthResponse login(LoginRequest request) {

        UserAuth user = userAuthRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new CustomException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash()))
            throw new CustomException("Invalid credentials");

        refreshTokenRepository.deleteByUserId(user.getUserId());

        String accessToken = jwtService.generateAccessToken(user.getEmail(), user.getRole().name());
        String refreshToken = jwtService.generateRefreshToken(user.getEmail());

        saveRefreshToken(user.getUserId(), refreshToken);

        return new AuthResponse(user.getUserId(), accessToken, refreshToken, user.getRole().name());
    }

    // ================= REFRESH =================

    @Override
    @Transactional
    public AuthResponse refreshToken(RefreshRequest request) {

        RefreshToken token = refreshTokenRepository.findByToken(request.getRefreshToken())
                .orElseThrow(() -> new CustomException("Invalid refresh token"));

        if (token.getExpiryDate().isBefore(LocalDateTime.now())) {
            refreshTokenRepository.deleteByToken(token.getToken());
            throw new CustomException("Refresh token expired");
        }

        UserAuth user = userAuthRepository.findByUserId(token.getUserId())
                .orElseThrow(() -> new CustomException("User not found"));

        String newAccessToken = jwtService.generateAccessToken(user.getEmail(), user.getRole().name());

        return new AuthResponse(user.getUserId(), newAccessToken, token.getToken(), user.getRole().name());
    }

    // ================= LOGOUT =================

    @Override
    @Transactional
    public void logout(RefreshRequest request) {
        refreshTokenRepository.deleteByToken(request.getRefreshToken());
    }

    // ================= PROFILE =================

    @Override
    public UserProfileResponse getProfile(String email) {

        UserAuth user = userAuthRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException("User not found"));

        UserProfile profile = userProfileRepository.findByUserId(user.getUserId())
                .orElseThrow(() -> new CustomException("Profile not found"));

        return mapToProfileResponse(user, profile);
    }

    @Override
    @Transactional
    public UserProfileResponse updateProfile(String email, RegisterRequest request) {

        UserAuth user = userAuthRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException("User not found"));

        UserProfile profile = userProfileRepository.findByUserId(user.getUserId())
                .orElseThrow(() -> new CustomException("Profile not found"));

        profile.setFullName(request.getFullName());
        profile.setPhoneNumber(request.getPhoneNumber());
        profile.setAddress(request.getAddress());
        profile.setCity(request.getCity());
        profile.setState(request.getState());
        profile.setPincode(request.getPincode());

        userProfileRepository.save(profile);

        return mapToProfileResponse(user, profile);
    }

    // ================= CHANGE PASSWORD =================

    @Override
    @Transactional
    public void changePassword(String email, ChangePasswordRequest request) {

        UserAuth user = userAuthRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException("User not found"));

        if (!passwordEncoder.matches(request.getOldPassword(), user.getPasswordHash()))
            throw new CustomException("Old password incorrect");

        if (!PasswordValidator.isValid(request.getNewPassword()))
            throw new CustomException("New password is weak");

        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        userAuthRepository.save(user);
    }

    // ================= FORGOT PASSWORD =================

    @Override
    @Transactional
    public void forgotPassword(ForgotPasswordRequest request) {

        userAuthRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new CustomException("Email not registered"));

        String otp = OtpGenerator.generateOtp();

        PasswordResetOtp resetOtp = new PasswordResetOtp();
        resetOtp.setEmail(request.getEmail());
        resetOtp.setOtp(otp);
        resetOtp.setExpiryTime(LocalDateTime.now().plusMinutes(5));
        resetOtp.setVerified(false);

        otpRepository.deleteByEmail(request.getEmail());
        otpRepository.save(resetOtp);

        emailService.sendOtpEmail(request.getEmail(), otp);
    }

    @Override
    @Transactional
    public void verifyOtp(VerifyOtpRequest request) {

        PasswordResetOtp storedOtp = otpRepository
                .findTopByEmailOrderByIdDesc(request.getEmail())
                .orElseThrow(() -> new CustomException("OTP not found"));

        if (storedOtp.getExpiryTime().isBefore(LocalDateTime.now()))
            throw new CustomException("OTP expired");

        if (!storedOtp.getOtp().equals(request.getOtp()))
            throw new CustomException("Invalid OTP");

        storedOtp.setVerified(true);
        otpRepository.save(storedOtp);
    }

    @Override
    @Transactional
    public void resetPassword(ResetPasswordRequest request) {

        PasswordResetOtp storedOtp = otpRepository
                .findTopByEmailOrderByIdDesc(request.getEmail())
                .orElseThrow(() -> new CustomException("OTP verification required"));

        if (!storedOtp.isVerified())
            throw new CustomException("OTP not verified");

        UserAuth user = userAuthRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new CustomException("User not found"));

        if (!PasswordValidator.isValid(request.getNewPassword()))
            throw new CustomException("Weak password");

        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        userAuthRepository.save(user);

        otpRepository.deleteByEmail(request.getEmail());
    }

    private void saveRefreshToken(String userId, String token) {

        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setUserId(userId);
        refreshToken.setToken(token);
        refreshToken.setExpiryDate(LocalDateTime.now().plusDays(7));

        refreshTokenRepository.save(refreshToken);
    }

    private UserProfileResponse mapToProfileResponse(UserAuth user, UserProfile profile) {

        return new UserProfileResponse(
                user.getUserId(),
                profile.getFullName(),
                user.getEmail(),
                profile.getPhoneNumber(),
                profile.getAddress(),
                profile.getCity(),
                profile.getState(),
                profile.getPincode(),
                user.getRole().name()
        );
    }
}