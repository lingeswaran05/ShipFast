export default function Footer() {
  return (
    <footer style={{ textAlign: "center", padding: "30px", color: "#94a3b8" }}>
      © 2026 ShipFast. Built for speed, trusted by people.
    </footer>
  );
}
