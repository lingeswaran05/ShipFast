import "../styles/heroBottom.css";

export default function HeroBottom() {
  return (
    <section className="hero-bottom">
      
    </section>
  );
}
